// -----------------------------------------------------------------------------
// Neptune Marine Intelligence Platform
// -----------------------------------------------------------------------------
// File: marine_conditions.dart
//
// Purpose:
// Represents the complete set of environmental and marine conditions used by
// Neptune's intelligence engine.
//
// This model is designed to evolve as Neptune's prediction engine grows.
// -----------------------------------------------------------------------------

class MarineConditions {
  /// Wind speed (km/h).
  final double windSpeed;

  /// Wind direction (e.g. N, NE, SW).
  final String windDirection;

  /// Swell height (m).
  final double swellHeight;

  /// Swell period (seconds).
  final double swellPeriod;

  /// Sea surface temperature (°C).
  final double waterTemperature;

  /// Air temperature (°C).
  final double airTemperature;

  /// Atmospheric pressure (hPa).
  final double atmosphericPressure;

  /// Tide description used by the UI.
  final String tide;

  /// Tide height (m).
  final double tideHeight;

  /// Tide state.
  final String tideState;

  /// Next predicted high tide.
  final DateTime? nextHighTide;

  /// Next predicted low tide.
  final DateTime? nextLowTide;

  /// Moon phase.
  final String moonPhase;

  /// Sunrise.
  final DateTime sunrise;

  /// Sunset.
  final DateTime sunset;

  const MarineConditions({
    required this.windSpeed,
    required this.windDirection,
    required this.swellHeight,
    required this.swellPeriod,
    required this.waterTemperature,
    required this.airTemperature,
    required this.atmosphericPressure,
    required this.tide,
    required this.tideHeight,
    required this.tideState,
    required this.nextHighTide,
    required this.nextLowTide,
    required this.moonPhase,
    required this.sunrise,
    required this.sunset,
  });

  MarineConditions copyWith({
    double? windSpeed,
    String? windDirection,
    double? swellHeight,
    double? swellPeriod,
    double? waterTemperature,
    double? airTemperature,
    double? atmosphericPressure,
    String? tide,
    double? tideHeight,
    String? tideState,
    DateTime? nextHighTide,
    DateTime? nextLowTide,
    String? moonPhase,
    DateTime? sunrise,
    DateTime? sunset,
  }) {
    return MarineConditions(
      windSpeed: windSpeed ?? this.windSpeed,
      windDirection: windDirection ?? this.windDirection,
      swellHeight: swellHeight ?? this.swellHeight,
      swellPeriod: swellPeriod ?? this.swellPeriod,
      waterTemperature: waterTemperature ?? this.waterTemperature,
      airTemperature: airTemperature ?? this.airTemperature,
      atmosphericPressure:
      atmosphericPressure ?? this.atmosphericPressure,
      tide: tide ?? this.tide,
      tideHeight: tideHeight ?? this.tideHeight,
      tideState: tideState ?? this.tideState,
      nextHighTide: nextHighTide ?? this.nextHighTide,
      nextLowTide: nextLowTide ?? this.nextLowTide,
      moonPhase: moonPhase ?? this.moonPhase,
      sunrise: sunrise ?? this.sunrise,
      sunset: sunset ?? this.sunset,
    );
  }
}