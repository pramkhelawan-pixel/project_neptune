import '../data/knowledge_repository_impl.dart';
import '../domain/knowledge_record.dart';

class KnowledgeService {
  final KnowledgeRepositoryImpl repository;

  const KnowledgeService({
    required this.repository,
  });

  List<KnowledgeRecord> shadBaits() {
    return repository.byCategory(
      'Shad',
      'bait',
    );
  }

  List<KnowledgeRecord> shadKnowledge() {
    return repository.forSpecies(
      'Shad',
    );
  }
}