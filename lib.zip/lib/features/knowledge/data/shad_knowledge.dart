import '../domain/evidence_level.dart';
import '../domain/knowledge_category.dart';
import '../domain/knowledge_record.dart';
import '../domain/knowledge_source.dart';

final shadKnowledge = <KnowledgeRecord>[
  KnowledgeRecord(
    id: 'NKB-SHD-BAIT-0001',
    species: 'Shad',
    category: KnowledgeCategory.bait,
    title: 'Fresh Sardine',
    description:
    'Fresh sardine is one of the highest confidence natural baits for targeting Shad along the KwaZulu-Natal coastline.',

    evidenceLevel: EvidenceLevel.experiencedAngler,

    confidence: 0.94,

    sources: [
      KnowledgeSource(
        name: 'Neptune Research',
        type: 'Knowledge',
        reference: 'NKB-001',
        reliability: 0.90,
      ),
    ],

    regions: [
      'KwaZulu-Natal',
    ],

    seasons: [
      'Winter',
    ],

    tags: [
      'bait',
      'fresh sardine',
      'shad',
    ],

    lastUpdated: DateTime(
      2026,
      7,
      27,
    ),
  ),
];