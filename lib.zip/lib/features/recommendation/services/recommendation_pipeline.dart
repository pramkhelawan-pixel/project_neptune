import '../domain/recommendation_request.dart';
import '../domain/recommendation_response.dart';
import 'confidence_engine.dart';
import 'recommendation_engine.dart';
import 'score_engine.dart';

class RecommendationPipeline {
  RecommendationPipeline({
    RecommendationEngine? recommendationEngine,
  }) : _recommendationEngine =
      recommendationEngine ??
          RecommendationEngine(
            scoreEngine: const ScoreEngine(),
            confidenceEngine: const ConfidenceEngine(),
          );

  final RecommendationEngine _recommendationEngine;

  RecommendationResponse execute(
      RecommendationRequest request,
      ) {
    final recommendation = _recommendationEngine.build(
      species: request.species,
      bait: 'Fresh Sardine',
      location: request.location,
      bestTime: 'Sunrise',
      weights: const [15, 20, 18],
      reasons: const [
        'Incoming tide',
        'Moderate swell',
        'Light offshore wind',
      ],
    );

    return RecommendationResponse(
      species: recommendation.species,
      bait: recommendation.bait,
      location: recommendation.location,
      bestTime: recommendation.bestTime,
      confidence: recommendation.confidence,
      explanations: recommendation.reasons,
    );
  }
}