import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/repositories/marine_repository_impl.dart';
import '../../domain/models/marine_conditions.dart';
import '../../domain/repositories/marine_repository.dart';

final marineRepositoryProvider = Provider<MarineRepository>(
      (ref) => MarineRepositoryImpl(),
);

final marineConditionsProvider =
FutureProvider<MarineConditions>((ref) async {
  final repository = ref.watch(marineRepositoryProvider);

  return repository.getCurrentConditions();
});